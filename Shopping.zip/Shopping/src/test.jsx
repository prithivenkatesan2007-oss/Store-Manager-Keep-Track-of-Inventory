import { useState } from "react";
import { data } from "react-router-dom";

function Tests(){


    const [datas, UpdateDatas] = useState([])
    const [temp, Gettemp] = useState("")


    return(
        <>

        <input type="text"  onInput={(e)=>{
            Gettemp(e.target.value)
        }}/>

        <button className="btn btn-primary" onClick={()=>{
            UpdateDatas([...datas,temp])
        }}>ADD</button>

        <button className="btn btn-danger" onClick={()=>{
            UpdateDatas(datas.filter((val,idx)=>idx!==0))
            
        }}>DELETE</button>

        {
            datas.map((val)=>(
                <>
                 <div className="card">
                    <h1>{val}</h1>
                 </div>
                </>
            ))
        }
        </>
    )
}

export default Tests;
