import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import ProductList from './pages/Productlist'
import AddProduct from './pages/Addproduct'
import EditProduct from './pages/Editproduct'
import Cart from './pages/cart'
import Tests from './test'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<ProductList />} />
        <Route path="/add" element={<AddProduct />} />
        <Route path="/edit/:id" element={<EditProduct />} />
        <Route path='/cart' element={<Cart />} />
        <Route path='/test' element={<Tests />} />
      </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
