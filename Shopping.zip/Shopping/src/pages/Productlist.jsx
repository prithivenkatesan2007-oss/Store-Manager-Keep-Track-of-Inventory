import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';
import { addToCart } from '../features/cart/cartSlice';

const ProductList = () => {
  const products = useSelector((state) => state.products.items);
  const dispatch = useDispatch();

  const [searchTerm, setSearchTerm] = useState('');

  const handleAddToCart = (product) => {
    dispatch(addToCart(product));
  };

  const filteredProducts = products.filter((product) =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div>
      {/* Navbar */}
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
        <div className="container">
          <Link className="navbar-brand" to="/">MyShop</Link>
          <div>
            <Link className="nav-link d-inline text-white me-3" to="/add">Add Product</Link>
            <Link className="nav-link d-inline text-white" to="/cart">Cart</Link>
          </div>
        </div>
      </nav>

      <div className="container mt-4">
        {/* Page Title */}
        <h2 className="mb-4 text-center text-white">Product List</h2>

        {/* Search Bar */}
        <div className="row justify-content-center mb-4">
          <div className="col-md-6">
            <input
              type="text"
              className="form-control"
              placeholder="Search products..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        {/* Product Cards */}
        <div className="row">
          {filteredProducts.length > 0 ? (
            filteredProducts.map((product) => (
              <div key={product.id} className="col-md-4 col-lg-3 mb-4">
                <div
                  className={`card h-100 shadow-sm ${
                    product.stock === 0 ? 'border-danger bg-danger' : ''
                  }`}
                >
                  {product.image ? (
                    <img
                      src={product.image}
                      className="card-img-top"
                      alt={product.name}
                      style={{ height: '200px', objectFit: 'cover' }}
                    />
                  ) : (
                    <div
                      className="d-flex align-items-center justify-content-center bg-light"
                      style={{ height: '200px' }}
                    >
                      <span className="text-muted">No Image</span>
                    </div>
                  )}

                  <div className="card-body d-flex flex-column">
                    <h5 className="card-title">{product.name}</h5>
                    <p className="card-text">₹ {product.price}</p>
                    <p className="card-text">Stock: {product.stock}</p>

                    {product.stock === 0 && (
                      <p className="fw-bold">Out of Stock</p>
                    )}

                    <div className="mt-auto">
                      <button
                        className="btn btn-primary me-2 mb-2"
                        onClick={() => handleAddToCart(product)}
                        disabled={product.stock === 0}
                      >
                        Add to Cart
                      </button>
                      <Link to={`/edit/${product.id}`} className="btn btn-secondary mb-2">
                        Edit
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <p className="text-center">No products found.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductList;
