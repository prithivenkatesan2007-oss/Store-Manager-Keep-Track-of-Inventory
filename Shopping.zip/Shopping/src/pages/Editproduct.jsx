import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { editProduct } from '../features/products/productSlice';
import { Link, useNavigate, useParams } from 'react-router-dom';
import ProductForm from '../features/products/productFrom';

const EditProduct = () => {
  const { id } = useParams();
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const product = useSelector((state) =>
    state.products.items.find((p) => p.id === Number(id))
  );

  const handleEdit = (updatedProduct) => {
    dispatch(editProduct(updatedProduct));
    navigate('/');
  };

  return (

    <>
    {/* Navbar */}
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
        <div className="container">
          <Link className="navbar-brand" to="/">MyShop</Link>
          <div>
            <Link className="nav-link d-inline text-white me-3" to="/add">Add Product</Link>
            <Link className="nav-link d-inline text-white" to="/cart">Cart</Link>
          </div>
        </div>
      </nav>
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-8 col-lg-6">
          <div className="card shadow-sm">
            <div className="card-body">
              {/* <h2 className="card-title mb-4 text-center">Edit Product</h2> */}

              {product ? (
                <ProductForm initialData={product} onSubmit={handleEdit} />
              ) : (
                <p className="text-danger text-center">Product not found</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
    </>
  );
};

export default EditProduct;
