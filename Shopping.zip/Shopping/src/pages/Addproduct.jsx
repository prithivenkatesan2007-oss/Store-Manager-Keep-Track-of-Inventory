import React from 'react';
import { useDispatch } from 'react-redux';
import { addProduct } from '../features/products/productSlice';
import ProductForm from '../features/products/productFrom';
import { Link, useNavigate } from 'react-router-dom';

const AddProduct = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleAdd = (product) => {
    dispatch(addProduct(product));
    navigate('/');
  };

  return (
    <>
     <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
        <div className="container">
          <Link className="navbar-brand" to="/">MyShop</Link>
          <div>
            <Link className="nav-link d-inline text-white me-3" to="/add">Add Product</Link>
            <Link className="nav-link d-inline text-white" to="/cart">Cart</Link>
          </div>
        </div>
      </nav>
    <div>
      <h2>Add Product</h2>
      <ProductForm onSubmit={handleAdd} />
    </div>
    </>
  );
};

export default AddProduct;
