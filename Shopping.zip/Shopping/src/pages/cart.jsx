import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { removeFromCart } from '../features/cart/cartSlice';
import { Link } from 'react-router-dom';

const Cart = () => {
  const cartItems = useSelector((state) => state.cart.items);
  const dispatch = useDispatch();

  const handleRemove = (id) => {
    dispatch(removeFromCart(id));
  };

  const handleBuy = (product) => {
    alert(`You bought ${product.name} for ₹${product.price}`);
    // Enhance later with checkout logic
  };

  if (cartItems.length === 0) {
    return (
      <>
       <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
        <div className="container">
          <Link className="navbar-brand" to="/">MyShop</Link>
          <div>
            <Link className="nav-link d-inline text-white me-3" to="/add">Add Product</Link>
            <Link className="nav-link d-inline text-white" to="/cart">Cart</Link>
          </div>
        </div>
      </nav>
      
      <div className="container mt-5 text-center">
        <h2 className="text-white">Your cart is empty 🛒</h2>
      </div>
      </>
    );
  }

  return (

    <>
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
        <div className="container">
          <Link className="navbar-brand" to="/">MyShop</Link>
          <div>
            <Link className="nav-link d-inline text-white me-3" to="/add">Add Product</Link>
            <Link className="nav-link d-inline text-white" to="/cart">Cart</Link>
          </div>
        </div>
      </nav>
    <div className="container mt-4">
      <h2 className="mb-4 text-center">Your Cart</h2>
      <div className="row">
        {cartItems.map((item) => (
          <div key={item.id} className="col-md-4 col-lg-3 mb-4">
            <div className="card h-100 shadow-sm">
              <img
                src={item.image || 'https://via.placeholder.com/200?text=No+Image'}
                alt={item.name}
                className="card-img-top"
                style={{ height: '200px', objectFit: 'cover' }}
              />
              <div className="card-body d-flex flex-column">
                <h5 className="card-title">{item.name}</h5>
                <p className="card-text">₹ {item.price}</p>
                <p className="card-text">Quantity: {item.quantity}</p>

                <div className="mt-auto d-flex justify-content-between">
                  <button
                    className="btn btn-success"
                    onClick={() => handleBuy(item)}
                  >
                    Buy
                  </button>
                  <button
                    className="btn btn-danger"
                    onClick={() => handleRemove(item.id)}
                  >
                    Remove
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
    </>
  );
};

export default Cart;
