import React, { useState, useEffect } from 'react';

const ProductForm = ({ initialData = {}, onSubmit }) => {
  const [product, setProduct] = useState({
    id: initialData.id || Date.now(),
    name: initialData.name || '',
    price: initialData.price || '',
    image: initialData.image || '',
    stock: initialData.stock || 0,
  });

  useEffect(() => {
    if (initialData.id) {
      setProduct(initialData);
    }
  }, [initialData]);

  const handleChange = (e) => {
    setProduct({ ...product, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(product);
  };

  // Styles
  const formStyle = {
    maxWidth: '500px',
    margin: '40px auto',
    padding: '30px',
    borderRadius: '10px',
    backgroundColor: '#f9f9f9',
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
  };

  const inputGroupStyle = {
    marginBottom: '20px',
  };

  const labelStyle = {
    display: 'block',
    marginBottom: '6px',
    fontWeight: 'bold',
    color: '#333',
  };

  const inputStyle = {
    width: '100%',
    padding: '10px',
    borderRadius: '6px',
    border: '1px solid #ccc',
    fontSize: '16px',
  };

  const buttonStyle = {
    backgroundColor: '#007bff',
    color: 'white',
    padding: '10px 20px',
    border: 'none',
    borderRadius: '6px',
    fontSize: '16px',
    cursor: 'pointer',
  };

  const imagePreviewStyle = {
    width: '100%',
    height: '200px',
    objectFit: 'cover',
    borderRadius: '8px',
    marginTop: '10px',
  };

  return (
    <form onSubmit={handleSubmit} style={formStyle}>
      <h2 style={{ textAlign: 'center' }}>
        {initialData.id ? 'Edit Product' : 'Add Product'}
      </h2>

      <div style={inputGroupStyle}>
        <label style={labelStyle}>Name:</label>
        <input
          name="name"
          value={product.name}
          onChange={handleChange}
          style={inputStyle}
          required
        />
      </div>

      <div style={inputGroupStyle}>
        <label style={labelStyle}>Price:</label>
        <input
          name="price"
          type="number"
          value={product.price}
          onChange={handleChange}
          style={inputStyle}
          required
        />
      </div>

      <div style={inputGroupStyle}>
        <label style={labelStyle}>Image URL:</label>
        <input
          name="image"
          value={product.image}
          onChange={handleChange}
          style={inputStyle}
        />
        {product.image && (
          <img
            src={product.image}
            alt="Preview"
            style={imagePreviewStyle}
          />
        )}
      </div>

      <div style={inputGroupStyle}>
        <label style={labelStyle}>Stock:</label>
        <input
          name="stock"
          type="number"
          value={product.stock}
          onChange={handleChange}
          style={inputStyle}
          required
        />
      </div>

      <div style={{ textAlign: 'center' }}>
        <button type="submit" style={buttonStyle}>
          {initialData.id ? 'Update Product' : 'Add Product'}
        </button>
      </div>
    </form>
  );
};

export default ProductForm;
